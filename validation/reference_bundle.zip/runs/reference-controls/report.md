# FDE-Bench execution

Scope: public authored synthetic workflow. Real customer case families: 0. No human/AGI claim.

| System | Seed | Session | Approved deployment | Correct on time | Operator minutes |
|---|---:|---|---|---:|---:|
| baseline-control | 101 | finished | True | 14 | 240 |
| baseline-control | 102 | finished | True | 11 | 240 |
| baseline-control | 103 | finished | True | 10 | 240 |
| routing-control | 101 | finished | True | 75 | 80 |
| routing-control | 102 | finished | True | 74 | 80 |
| routing-control | 103 | finished | True | 73 | 80 |

Inspect results.json and each episode's SQLite transaction ledger. There is no aggregate score or automatic overall ranking.
