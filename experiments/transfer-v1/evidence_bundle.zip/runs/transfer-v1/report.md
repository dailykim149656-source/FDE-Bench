# Frozen-instruction transfer pilot

Two synthetic mechanisms. Real customer families: 0. One agent sample per condition.
All development sessions and deployments froze before held-out workload evaluation.

| Case | Arm | Session | Rejections | Deployed | Source mean SLA | Target checkpoints |
|---|---|---|---:|---|---:|---|
| support | neutral | finished | 0 | True | 180 | n/a |
| inventory | ancestor | finished | 1 | True | n/a | 9/9 |
| support | source_revised | finished | 0 | True | 156.33333333333334 | n/a |
| inventory | neutral | finished | 1 | True | n/a | 9/9 |
| support | ancestor | finished | 0 | True | 180 | n/a |
| inventory | source_revised | finished | 0 | True | n/a | 9/9 |

Inventory requires exact stock and no stale/duplicate writes at every checkpoint.
Schema rejection measures prompt/API portability; it cannot establish intelligence.
Seeds are not independent projects. No p-values, cross-case score, or AGI claim.
results.json retains baseline/candidate metrics, failures and usage. SQLite files retain transactions.
