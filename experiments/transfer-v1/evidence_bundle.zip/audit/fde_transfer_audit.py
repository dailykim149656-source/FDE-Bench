import json, hashlib, sqlite3
from pathlib import Path
from fdebench.artifacts import canonical, source_identity
root=Path('runs/transfer-v1'); read=lambda p:json.loads(p.read_text()); sha=lambda b:hashlib.sha256(b).hexdigest()
m=read(root/'manifest.json'); f=read(root/'deployments.freeze.json')
assert sha((root/'results.json').read_bytes())==m['results_sha256']
assert source_identity()==m['evaluator_version']==f['evaluator_version']
assert sha((root/'registration.json').read_bytes())==f['registration_sha256']
for d in f['deployments']:
 s=root/f"{d['case']}-{d['arm']}"/'session.json'
 assert sha(canonical(read(s)['session']['policy']))==d['policy_sha256']
 assert sha((root/'agents'/f"{d['arm']}.source").read_bytes())==d['source_sha256']
 assert s.stat().st_mtime_ns <= (root/'deployments.freeze.json').stat().st_mtime_ns
count=0; databases=set(); baselines={}
for e in root.glob('*/evaluation-*/evaluation.json'):
 assert e.stat().st_mtime_ns >= (root/'deployments.freeze.json').stat().st_mtime_ns
 data=read(e)
 for side in ('baseline','candidate'):
  for p in data[side]:
   path=Path(p['database_path']); databases.add(path.resolve())
   db=sqlite3.connect(path.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
   assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
   if data['case']=='support':
    db.row_factory=sqlite3.Row
    evidence=[dict(r) for r in db.execute('select * from ledger order by seq')]
   else:
    phase=p['phase']; end=db.execute('select max(id) from arrivals where phase=?',(phase,)).fetchone()[0]
    stock={r[0]:r[1] for r in db.execute('select entity_id,after_quantity from effects where arrival_id<=? order by arrival_id',(end,))}
    rows=[list(r) for r in db.execute('SELECT l.arrival_id,l.phase,l.decision,l.before_quantity,l.after_quantity,l.stale_write,l.duplicate_write,a.entity_id,a.event_id,a.revision,a.quantity FROM ledger l JOIN arrivals a ON a.id=l.arrival_id WHERE l.phase=? ORDER BY l.arrival_id',(phase,))]
    evidence={'phase':phase,'ledger':rows,'stock':stock}
    truth=dict(db.execute('select entity_id,quantity from truth where phase=?',(phase,)))
    assert sum(stock.get(k)==v for k,v in truth.items())==p['metrics']['correct_entities']
    assert sum(abs(stock.get(k,0)-v) for k,v in truth.items())==p['metrics']['absolute_error_units']
   assert sha(canonical(evidence))==p['ledger_sha256'],str(path)
   key=(data['case'],data['seed'],p['phase'])
   if side=='baseline':
    value=(p['workload_sha256'],p['ledger_sha256'])
    assert baselines.setdefault(key,value)==value
   else: assert baselines[key][0]==p['workload_sha256']
   db.close();count+=1
out={'evaluator_version':source_identity(),'results_sha256':m['results_sha256'],'database_integrity_checks':len(databases),'phase_ledger_hashes_verified':count,'source_policy_registration_hashes':'matched','baseline_across_arms':'identical per case/seed/phase','candidate_baseline_workloads':'matched','freeze_file_order':'all sessions before freeze; evaluations after freeze','inventory_checkpoint_quality':'recomputed from persisted effects and truth','scope':'Artifact consistency audit by implementing team, not independent scientific validation'}
Path('experiments/transfer-v1/artifact-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
